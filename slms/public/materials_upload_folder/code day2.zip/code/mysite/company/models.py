from __future__ import unicode_literals

from django.db import models

# Create your models here.
class Company(models.Model):
	company_name = models.CharField(max_length=100)
	
	def __str__(self):
		return self.company_name


class Department(models.Model):
	department_name = models.CharField(max_length=100)
	company = models.ForeignKey(Company,on_delete=models.CASCADE)

	def __str__(self):
		return self.department_name

class Employee(models.Model):
	employee_name = models.CharField(max_length=100)
	department = models.ForeignKey(Department,on_delete=models.CASCADE)

	def __str__(self):
		return self.employee_name
	
