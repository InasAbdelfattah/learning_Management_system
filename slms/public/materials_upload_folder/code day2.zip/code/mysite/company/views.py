from django.shortcuts import render
from django.http import HttpResponse
from .models import *

# Create your views here.
def index(request,company_id):
	company = Company.objects.get(pk=company_id)
	depts = company.department_set.all()
	output ='<ul>'
	output +="<b>"+company.company_name+"</b>"
	for dept in depts:
		output +="<li>"+dept.department_name+"</li>"
	output +="</ul>"
	return HttpResponse(output)

def dept(request,dept_id):
	department = Department.objects.get(pk=dept_id)
	emps = department.employee_set.all()
	output ='<ul>'
	output +="<b>"+department.department_name+"</b>"
	for emp in emps:
		output +="<li>"+emp.employee_name+"</li>"
	output +="</ul>"
	return HttpResponse(output)


def emp(request,emp_id):
	employee = Employee.objects.get(pk=emp_id)
	output = employee.employee_name+"----"
	output += employee.department.department_name +"--->"
	output += employee.department.company.company_name
	return HttpResponse(output)






