
from django.shortcuts import render
from django.http import HttpResponse
import datetime
from .models import *

# Create your views here.
def hello(request):
	return HttpResponse("Hello World")


def current_date(request):
	now = datetime.datetime.now()
	return HttpResponse("<b>%s</b>"% now)


def index(request) :
	latest_questions = Question.objects.all()[:2]
	context = {'questions':latest_questions}
	return render(request,'polls/index.html',context)




	# output = "<br/>".join([q.question_text for q in latest_questions])
	# output =''
	# for q in latest_questions:
	# 	output +="<a href='/polls/"+str(q.id)+"/details/'>"+q.question_text+"</a><br/>"

	# return HttpResponse(output)
	
# def test(request,id1,id2):
# 	return HttpResponse("id1 is "+str(id1)+", id2 is "+str(id2))

def results(request,question_id):
	try:
		question = Question.objects.get(pk=question_id)
		# output +="<li>".join([choice.choice_text+"</li>" for choice in choices])

	except Question.DoesNotExist:
		return render(request,'polls/result.html',{'error_message':'Question does not Exist'})
	return render(request,'polls/result.html',{'question':question})
	
def details(request,question_id):
	try:
		question = Question.objects.get(pk=question_id)
		# output +="<li>".join([choice.choice_text+"</li>" for choice in choices])
	except Question.DoesNotExist:
		return render(request,'polls/details.html',{'error_message':'Question does not Exist'})
	if "vote" in request.session:
		page = "polls/result.html"
	else:
		page = "polls/details.html"

	return render(request,page,{'question':question})
	

def vote(request,question_id):
	question = Question.objects.get(pk=question_id)
	if "choice" in request.POST:
		choice_id = request.POST['choice']
		choice = Choice.objects.get(pk=choice_id)
		choice.votes +=1
		choice.save()
		request.session["vote"] = "done"
		
		# if "vote" in request.COOKIES:
		# 	print "coockie is set"
		# else:
		# 	set_cookie("vote","done")
		# del request.session["vote"]

		return render(request,'polls/result.html',{'question':question})
	else:
		return render(request,'polls/details.html',{'error_message':'No Choice '})











