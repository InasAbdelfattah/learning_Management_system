from django.conf.urls import url
from .views import *


urlpatterns = [
    url(r'^$',index),
    url(r'^(?P<question_id>[0-9]+)/details/$',details),
    url(r'^(?P<question_id>[0-9]+)/results/$',results),
    url(r'^(?P<question_id>[0-9]+)/votes/$',vote),
    # url(r'^question/(?P<id1>[0-9]+)/ahmed/(?P<id2>[0-9]+)/$',test),
    url(r'^hello/',hello),
    url(r'^whatnow/',current_date),
    url(r'^whatnow/',current_date),

    
]
